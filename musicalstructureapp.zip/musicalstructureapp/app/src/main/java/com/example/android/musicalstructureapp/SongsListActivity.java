package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;

public class SongsListActivity extends AppCompatActivity {
    ListView songList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.songs_list);

        // Create 20 songs to populate the list view
        String songName = getResources().getString(R.string.song_name);
        String songAuthor = getResources().getString(R.string.song_author);
        int songsCount = 20;
        //int i = 0;
        ArrayList<Song> songsList = new ArrayList<>();

        for(int i = 0 ; i < songsCount; i++){
            Song song = new Song();
            song.setmSongAuthor(songAuthor);
            song.setmSongTitle(songName);
            songsList.add(song);
        }


        // Setting an adapter on the list view
        songList = (ListView) findViewById(R.id.songs_list);
        songList.setAdapter(new SongsAdapter(this, songsList ));

        // Setting the onclicklistener on the add_song button
        FloatingActionButton addSongsFab = (FloatingActionButton) findViewById(R.id.add_songs);
        addSongsFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent addSongs = new Intent(getApplicationContext(), AddSongsActivity.class);
                startActivity(addSongs);
            }
        });

    }
}
