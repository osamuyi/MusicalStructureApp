package com.example.android.musicalstructureapp;

public class Song {

    // song author
    private String mSongAuthor;

    // Song title
    private String mSongTitle;

    public Song(){}

    public Song(String songAuthor, String songTitle){
        mSongAuthor = songAuthor;
        mSongTitle = songTitle;
    }

    public String getmSongAuthor() {
        return mSongAuthor;
    }

    public void setmSongAuthor(String mSongAuthor) {
        this.mSongAuthor = mSongAuthor;
    }

    public String getmSongTitle() {
        return mSongTitle;
    }

    public void setmSongTitle(String mSongTitle) {
        this.mSongTitle = mSongTitle;
    }
}
