package com.example.android.musicalstructureapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

class SongsAdapter extends BaseAdapter {

    Context context;
    ArrayList<Song> data;
    private static LayoutInflater inflater = null;

    public SongsAdapter(Context context, ArrayList<Song> data) {
        this.context = context;
        this.data = data;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View songItemLayout = convertView;
        if (songItemLayout == null)
            songItemLayout = inflater.inflate(R.layout.song_item, null);

        // Set the data on the views
        TextView songTitle = (TextView) songItemLayout.findViewById(R.id.song_title);
        TextView songAuthor = (TextView) songItemLayout.findViewById(R.id.song_author);

        // Iteration of the arraylist
        for (Song sg:data){
            songTitle.setText(sg.getmSongTitle());
            songAuthor.setText(sg.getmSongAuthor());
        }

        // Set an onClickListener on the song items to open the song details
        LinearLayout songItem = (LinearLayout) songItemLayout.findViewById(R.id.song_item);
        songItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent songDetails = new Intent(context, SongDetailsActivity.class);
                context.startActivity(songDetails);
            }
        });
        return songItemLayout;
    }
}