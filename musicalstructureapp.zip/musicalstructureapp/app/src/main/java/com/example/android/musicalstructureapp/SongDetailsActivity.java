package com.example.android.musicalstructureapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class SongDetailsActivity extends AppCompatActivity {

    // Declaring the variable for the image view
    private ImageView relatedImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.song_details);

        // Initiating the image view
        relatedImage = (ImageView) findViewById(R.id.related_song);
        relatedImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(v.getContext(), "This is my Toast message!",
                        Toast.LENGTH_LONG).show();
            }
        });
    }
}
